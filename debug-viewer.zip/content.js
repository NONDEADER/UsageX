'use strict';

if (typeof browser === "undefined") {
  var browser = chrome;
}

// Clean up any previously injected instance of the content script
if (window.__usagex_cleanup) {
  try {
    window.__usagex_cleanup();
  } catch (e) {
    console.error('[UsageX] Error running cleanup:', e);
  }
}

const UX_ID = 'usagex-v2-root';
const UX_STYLE_ID = 'usagex-v2-styles';
const IDLE_MS = 2 * 60 * 1000;
const TICK_MS = 10000;



let lastUrl = location.href;
let lastActive = Date.now();
let isIdle = false;
let sidebarInjected = false;
let isInjecting = false;

// Global tracking references for cleanups
let tryInjectInterval = null;
let urlCheckInterval = null;
let timeTrackingInterval = null;
let idleCheckInterval = null;
let pollInterval = null;
let globalObserver = null;
let dragMoveHandler = null;
let dragUpHandler = null;
let resetIdleHandler = null;
let windowMsgHandler = null;
let sidebarResizeObserver = null;

window.__usagex_cleanup = () => {
  if (tryInjectInterval) clearInterval(tryInjectInterval);
  if (urlCheckInterval) clearInterval(urlCheckInterval);
  if (timeTrackingInterval) clearInterval(timeTrackingInterval);
  if (idleCheckInterval) clearInterval(idleCheckInterval);
  if (pollInterval) clearInterval(pollInterval);

  if (globalObserver) {
    globalObserver.disconnect();
  }

  if (sidebarResizeObserver) {
    sidebarResizeObserver.disconnect();
  }

  if (resetIdleHandler) {
    ['mousemove','keydown','click','touchstart'].forEach(ev =>
      document.removeEventListener(ev, resetIdleHandler)
    );
  }

  if (dragMoveHandler) document.removeEventListener('mousemove', dragMoveHandler);
  if (dragUpHandler) document.removeEventListener('mouseup', dragUpHandler);
  if (windowMsgHandler) window.removeEventListener('message', windowMsgHandler);

  // Remove existing elements
  const existingWidget = document.getElementById(UX_ID);
  if (existingWidget) existingWidget.remove();
  const existingStyles = document.getElementById(UX_STYLE_ID);
  if (existingStyles) existingStyles.remove();
  const existingHook = document.getElementById('ux-fetch-hook');
  if (existingHook) existingHook.remove();

  console.log('[UsageX] Cleaned up previous script instance.');
};

// ─── Storage ───────────────────────────────────────────────────────────────────

async function loadToday() {
  const res = await browser.storage.local.get(['today', 'history', 'settings', 'usage_limits']);
  const todayDate = todayStr();
  if (!res.today || res.today.date !== todayDate) {
    const yesterday = res.today;
    if (yesterday) {
      const hist = res.history || [];
      hist.push(yesterday);
      if (hist.length > 30) hist.splice(0, hist.length - 30);
      await browser.storage.local.set({ history: hist });
    }
    await browser.storage.local.set({ today: freshToday() });
    return { today: freshToday(), settings: res.settings || defaultSettings(), usage_limits: res.usage_limits };
  }
  return { today: res.today, settings: res.settings || defaultSettings(), usage_limits: res.usage_limits };
}

async function saveToday(patch) {
  const res = await browser.storage.local.get('today');
  const today = res.today || freshToday();
  const updated = { ...today, ...patch, date: todayStr() };
  await browser.storage.local.set({ today: updated });
  return updated;
}

async function getSettings() {
  const res = await browser.storage.local.get('settings');
  return res.settings || defaultSettings();
}

async function saveSettings(patch) {
  const res = await browser.storage.local.get('settings');
  const s = { ...(res.settings || defaultSettings()), ...patch };
  await browser.storage.local.set({ settings: s });
  return s;
}

function freshToday() {
  return { date: todayStr(), msgs: 0, convos: 0, time_s: 0, tokens_est: 0, effort_breakdown: { low: 0, medium: 0, high: 0, max: 0 } };
}


function defaultSettings() { return { debug_logging: false, sidebar_side: 'left', timezone: 'auto', floating: false, float_x: null, float_y: null, floating_opacity_enabled: true, floating_opacity: 0.85 }; }
function todayStr() { return new Date().toISOString().slice(0, 10); }

function setupSidebarResizeObserver(root) {
  if (sidebarResizeObserver) {
    sidebarResizeObserver.disconnect();
  }
  if (!root) return;
  const parent = root.parentElement;
  if (!parent) return;

  sidebarResizeObserver = new ResizeObserver((entries) => {
    for (const entry of entries) {
      const width = entry.contentRect.width;
      const isFloating = root.classList.contains('ux-floating');
      if (!isFloating && width > 0 && width < 180) {
        root.classList.add('ux-parent-collapsed');
      } else {
        root.classList.remove('ux-parent-collapsed');
      }
    }
  });
  sidebarResizeObserver.observe(parent);
}

// ─── Timezone helpers ──────────────────────────────────────────────────────────

function getTimezoneName() {
  const formatter = new Intl.DateTimeFormat('en-US', {
    timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    timeZoneName: 'short'
  });
  const parts = formatter.formatToParts(new Date());
  return parts.find(p => p.type === 'timeZoneName')?.value || 'UTC';
}

function formatTimeAMPM(date) {
  const h = date.getHours() % 12 || 12;
  const m = date.getMinutes().toString().padStart(2, '0');
  const ampm = date.getHours() >= 12 ? 'PM' : 'AM';
  return `${h}:${m} ${ampm}`;
}

function formatResetTimeDisplay(timestamp, timezone) {
  if (!timestamp) return '-';
  const diff = timestamp - Date.now();
  if (diff <= 0) return 'resetting now';
  const resetDate = new Date(timestamp);
  const timeStr = formatTimeAMPM(resetDate);
  const hoursLeft = Math.floor(diff / (1000 * 60 * 60));
  const minutesLeft = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  let remaining;
  if (hoursLeft >= 24) {
    const days = Math.floor(hoursLeft / 24);
    remaining = `${days}d ${hoursLeft % 24}h remaining`;
  } else if (hoursLeft === 0) {
    remaining = `${minutesLeft}m remaining`;
  } else {
    remaining = `${hoursLeft}h ${minutesLeft}m remaining`;
  }
  return `${remaining} · resets ${timeStr} ${timezone}`;
}

function formatWeeklyResetDisplay(timestamp, timezone) {
  if (!timestamp) return '-';
  const resetDate = new Date(timestamp);
  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const day = dayNames[resetDate.getDay()];
  const date = resetDate.getDate();
  const month = monthNames[resetDate.getMonth()];
  const timeStr = formatTimeAMPM(resetDate);
  const diff = timestamp - Date.now();
  let remaining;
  if (diff <= 0) { remaining = 'resetting now'; }
  else {
    const hoursLeft = Math.floor(diff / (1000 * 60 * 60));
    const minutesLeft = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    if (hoursLeft >= 24) {
      const days = Math.floor(hoursLeft / 24);
      remaining = `${days}d ${hoursLeft % 24}h remaining`;
    } else if (hoursLeft === 0) { remaining = `${minutesLeft}m remaining`; }
    else { remaining = `${hoursLeft}h ${minutesLeft}m remaining`; }
  }
  return `${remaining} · resets ${date} ${month}, ${day} at ${timeStr} ${timezone}`;
}

// ─── Fetch interception (via injected MAIN-world script) ──────────────────────

function injectFetchHook() {
  if (document.getElementById('ux-fetch-hook')) return;
  const script = document.createElement('script');
  script.id = 'ux-fetch-hook';
  script.src = browser.runtime.getURL('inject.js');
  (document.head || document.documentElement).appendChild(script);
}

windowMsgHandler = (event) => {
  if (event.source !== window) return;
  if (event.data.type === '__ux_fetch_msg') {
    onMessageSent({ body: event.data.body }).catch(() => {});
  } else if (event.data.type === '__ux_usage_data') {
    browser.storage.local.set({ usage_limits: event.data.data }).catch(() => {});
    updateUI().catch(() => {});
  }
};
window.addEventListener('message', windowMsgHandler);

// ─── Message tracking ──────────────────────────────────────────────────────────

async function onMessageSent(req) {
  lastActive = Date.now();
  isIdle = false;
  const effort = detectEffort();
  let inputChars = 0;
  try {
    const body = JSON.parse(req.body);
    const lastMsg = body?.messages?.at(-1)?.content;
    if (typeof lastMsg === 'string') inputChars = lastMsg.length;
    else if (Array.isArray(lastMsg)) inputChars = lastMsg.map(b => b.text || '').join('').length;
  } catch (_) {}
  const inputTokens = Math.round(inputChars / 4);
  const thinkTokens = effortThinkTokens(effort);
  const tokenDelta = inputTokens + thinkTokens;
  const res = await browser.storage.local.get('today');
  const today = res.today || freshToday();
  const effortKey = effort.toLowerCase();
  const eb = today.effort_breakdown || { low: 0, medium: 0, high: 0, max: 0 };
  eb[effortKey] = (eb[effortKey] || 0) + 1;
  await saveToday({ msgs: today.msgs + 1, tokens_est: today.tokens_est + tokenDelta, effort_breakdown: eb });
  updateUI().catch(() => {});
  debugLog('msg_sent', { effort, inputTokens, thinkTokens });
  setTimeout(() => {
    fetchUsageLimitsActive().catch(() => {});
  }, 2000);
}

function effortThinkTokens(effort) {
  const map = { Low: 250, Medium: 1500, High: 6000, Max: 20000 };
  return map[effort] || 250;
}

function detectEffort() {
  const selectors = [
    '[data-testid="model-selector"]',
    'button[aria-label*="model"]',
    'button[aria-label*="effort"]',
    '[class*="model-selector"]',
    '[class*="ModelSelector"]',
  ];
  let text = '';
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el) { text = el.textContent || ''; break; }
  }
  if (!text) {
    document.querySelectorAll('button').forEach(btn => {
      const t = btn.textContent || '';
      if (t.match(/\b(Low|Medium|High|Max)\b/)) text = t;
    });
  }
  const match = text.match(/\b(Low|Medium|High|Max)\b/);
  return match ? match[1] : 'Low';
}

// ─── URL tracking ──────────────────────────────────────────────────────────────

function checkUrlChange() {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    if (location.pathname.startsWith('/chat/')) {
      browser.storage.local.get('today').then(res => {
        const today = res.today || freshToday();
        saveToday({ convos: today.convos + 1 });
      }).catch(() => {});
      debugLog('new_convo', { url: location.href });
    }
    setTimeout(() => updateUI().catch(() => {}), 500);
  }
}

// ─── Time tracking ─────────────────────────────────────────────────────────────

function startTimeTracking() {
  timeTrackingInterval = setInterval(() => {
    if (!isIdle) {
      browser.storage.local.get('today').then(res => {
        const today = res.today || freshToday();
        saveToday({ time_s: today.time_s + 10 }).catch(() => {});
      }).catch(() => {});
    }
  }, TICK_MS);

  resetIdleHandler = () => {
    lastActive = Date.now();
    if (isIdle) { isIdle = false; updateUI().catch(() => {}); }
  };
  ['mousemove','keydown','click','touchstart'].forEach(ev =>
    document.addEventListener(ev, resetIdleHandler, { passive: true })
  );
  idleCheckInterval = setInterval(() => {
    if (Date.now() - lastActive > IDLE_MS) isIdle = true;
  }, 30000);
}

// ─── UI Injection ──────────────────────────────────────────────────────────────

function injectStyles() {
  if (document.getElementById(UX_STYLE_ID)) return;
  const style = document.createElement('style');
  style.id = UX_STYLE_ID;
  style.textContent = getCSS();
  document.head.appendChild(style);
}

function findInjectTarget() {
  const userBtn = document.querySelector('[data-testid="user-menu-button"]');
  if (userBtn) {
    return userBtn.closest('nav') || userBtn.closest('[class*="sidebar"]') || userBtn.closest('[class*="Sidebar"]') || userBtn.closest('[class*="side"]') || userBtn.closest('div');
  }
  const strategies = [
    () => document.querySelector('nav[class*="sidebar"]'),
    () => document.querySelector('aside'),
    () => document.querySelector('[class*="Sidebar"]'),
    () => document.querySelector('[class*="sidebar"]'),
  ];
  for (const fn of strategies) {
    try { const el = fn(); if (el) return el; } catch (_) {}
  }
  return null;
}

function findUserProfileEl(sidebar) {
  const strategies = [
    () => sidebar.querySelector('[data-testid="user-menu-button"]'),
    () => sidebar.querySelector('[class*="UserMenu"]'),
    () => sidebar.querySelector('[class*="user-menu"]'),
    () => sidebar.querySelector('[class*="profile"]'),
  ];
  for (const fn of strategies) {
    try {
      const el = fn();
      if (el && el !== document.getElementById(UX_ID)) {
        let ancestor = el;
        while (ancestor && ancestor.parentElement !== sidebar) {
          ancestor = ancestor.parentElement;
        }
        if (ancestor) return ancestor;
      }
    } catch (_) {}
  }
  const children = [...sidebar.children];
  return children[children.length - 1] || null;
}

async function openDebugViewer() {
  const url = browser.runtime.getURL("debug-viewer.html");
  window.open(url, "usagex-debug-viewer", "width=800,height=600,menubar=no,toolbar=no");
}

async function injectSidebar() {
  if (isInjecting) return;
  if (document.getElementById(UX_ID)) { sidebarInjected = true; return; }
  const sidebar = findInjectTarget();
  if (!sidebar) return;
  const userProfile = findUserProfileEl(sidebar);
  if (!userProfile) return;
  isInjecting = true;
  try {
    injectStyles();
    const root = document.createElement('div');
    root.id = UX_ID;
    root.classList.add('font-sans');
    root.innerHTML = getSidebarHTML();

    // Apply saved mode classes before insertion
    const settingsRes = await browser.storage.local.get('settings');
    const s = settingsRes.settings || defaultSettings();
    if (s.floating) {
      root.classList.add('ux-floating');
      const fx = s.float_x != null ? s.float_x : window.innerWidth - 240;
      const fy = s.float_y != null ? s.float_y : window.innerHeight - 200;
      root.style.left = fx + 'px';
      root.style.top  = fy + 'px';
      document.body.appendChild(root);
    } else {
      if (s.sidebar_side === 'right') root.classList.add('ux-side-right');
      sidebar.insertBefore(root, userProfile);
    }
    sidebarInjected = true;
    setupSidebarResizeObserver(root);
    bindEvents();
    await updateUI();
    debugLog('injected', { sidebar: sidebar.tagName, floating: s.floating });
  } finally {
    isInjecting = false;
  }
}

// ─── UI Update ─────────────────────────────────────────────────────────────────

function clamp(v, min, max) { return Math.min(max, Math.max(min, v)); }

async function updateUI() {
  const root = document.getElementById(UX_ID);
  if (!root) return;

  const { today, settings, usage_limits } = await loadToday();
  const tz = settings.timezone === 'auto' ? getTimezoneName() : settings.timezone;

  // Usage % from API or DOM
  const sessionPct = usage_limits?.session_pct;
  const weeklyPct = usage_limits?.weekly_pct;

  setEl('#ux-session-pct', sessionPct != null ? `${sessionPct}%` : '—');
  setEl('#ux-weekly-pct', weeklyPct != null ? `${weeklyPct}%` : '—');

  // Progress bars
  setWidth('#ux-bar-session', clamp(sessionPct ?? 0, 0, 100));
  setWidth('#ux-bar-weekly', clamp(weeklyPct ?? 0, 0, 100));

  // Bar color red when > 80%
  const sessionBar = root.querySelector('#ux-bar-session');
  if (sessionBar) sessionBar.style.background = (sessionPct ?? 0) > 80 ? '#c0392b' : '#c9b89a';

  // Reset times
  if (usage_limits?.session_resets_at) {
    setEl('#ux-session-time', formatResetTimeDisplay(new Date(usage_limits.session_resets_at).getTime(), tz));
  } else {
    setEl('#ux-session-time', '');
  }
  if (usage_limits?.weekly_resets_at) {
    setEl('#ux-weekly-time', formatWeeklyResetDisplay(new Date(usage_limits.weekly_resets_at).getTime(), tz));
  } else {
    setEl('#ux-weekly-time', '');
  }

  // Debug count
  const dbgRes = await browser.storage.local.get('debug_logs');
  const dbgCount = (dbgRes.debug_logs || []).length;
  setEl('#ux-debug-count', `${dbgCount} logs`);

  // Settings panel state
  const dbgToggle  = root.querySelector('#ux-setting-debug');
  const sideSelect = root.querySelector('#ux-setting-side');
  const tzSelect   = root.querySelector('#ux-setting-timezone');
  const floatToggle = root.querySelector('#ux-setting-float');
  if (dbgToggle)   dbgToggle.checked   = settings.debug_logging !== false;
  if (sideSelect)  sideSelect.value    = settings.sidebar_side || 'left';
  if (tzSelect)    tzSelect.value      = settings.timezone || 'auto';
  if (floatToggle) floatToggle.checked = settings.floating === true;

  const isFloating = settings.floating === true;
  const isOpacityEnabled = settings.floating_opacity_enabled !== false;
  const opacityVal = settings.floating_opacity != null ? settings.floating_opacity : 0.85;

  const opacityRow = root.querySelector('#ux-opacity-slider-row');
  if (opacityRow) {
    opacityRow.style.display = (isFloating && isOpacityEnabled) ? 'flex' : 'none';
  }

  const opacitySlider = root.querySelector('#ux-setting-opacity-slider');
  if (opacitySlider) {
    const sliderVal = Math.round(opacityVal * 100);
    opacitySlider.value = sliderVal;
    const pct = ((sliderVal - 10) / (100 - 10)) * 100;
    opacitySlider.style.setProperty('--ux-slider-pct', `${pct}%`);
  }

  const opacityValText = root.querySelector('#ux-opacity-val');
  if (opacityValText) {
    opacityValText.textContent = `${Math.round(opacityVal * 100)}%`;
  }

  const opacityToggle = root.querySelector('#ux-setting-floating-opacity-enabled');
  if (opacityToggle) {
    opacityToggle.checked = isOpacityEnabled;
  }

  if (isFloating && isOpacityEnabled) {
    root.style.setProperty('--ux-floating-opacity', String(opacityVal));
  } else {
    root.style.setProperty('--ux-floating-opacity', '1');
  }
}

function setEl(sel, text) {
  const root = document.getElementById(UX_ID);
  if (!root) return;
  const el = root.querySelector(sel);
  if (el) el.textContent = text;
}

function setWidth(sel, pct) {
  const root = document.getElementById(UX_ID);
  if (!root) return;
  const el = root.querySelector(sel);
  if (el) el.style.width = `${Math.min(100, pct)}%`;
}

// ─── Event binding ─────────────────────────────────────────────────────────────

function bindEvents() {
  const root = document.getElementById(UX_ID);
  if (!root) return;

  root.querySelector('#ux-btn-minimize')?.addEventListener('click', () => {
    root.classList.toggle('ux-minimized');
  });

  root.querySelector('#ux-btn-settings')?.addEventListener('click', () => {
    root.classList.remove('ux-advanced-open');
    root.classList.toggle('ux-settings-open');
    updateUI().catch(() => {});
  });

  // Settings back → main view
  root.querySelector('#ux-settings-back-btn')?.addEventListener('click', () => {
    root.classList.remove('ux-settings-open');
    root.classList.remove('ux-advanced-open');
  });

  // Advanced back → settings
  root.querySelector('#ux-advanced-back-btn')?.addEventListener('click', () => {
    root.classList.remove('ux-advanced-open');
  });

  root.querySelector('#ux-advanced-btn')?.addEventListener('click', () => {
    root.classList.add('ux-advanced-open');
  });

  root.querySelector('#ux-btn-export')?.addEventListener('click', exportData);
  root.querySelector('#ux-btn-debug')?.addEventListener('click', () => openDebugViewer());

  root.querySelector('#ux-setting-debug')?.addEventListener('change', async (e) => {
    await saveSettings({ debug_logging: e.target.checked });
  });

  root.querySelector('#ux-setting-floating-opacity-enabled')?.addEventListener('change', async (e) => {
    await saveSettings({ floating_opacity_enabled: e.target.checked });
    updateUI().catch(() => {});
  });

  root.querySelector('#ux-setting-opacity-slider')?.addEventListener('input', (e) => {
    const val = parseFloat(e.target.value) / 100;
    root.style.setProperty('--ux-floating-opacity', String(val));
    const pct = ((parseFloat(e.target.value) - 10) / (100 - 10)) * 100;
    e.target.style.setProperty('--ux-slider-pct', `${pct}%`);
    const opacityValText = root.querySelector('#ux-opacity-val');
    if (opacityValText) {
      opacityValText.textContent = `${e.target.value}%`;
    }
  });

  root.querySelector('#ux-setting-opacity-slider')?.addEventListener('change', async (e) => {
    const val = parseFloat(e.target.value) / 100;
    await saveSettings({ floating_opacity: val });
  });

  root.querySelector('#ux-setting-side')?.addEventListener('change', async (e) => {
    const side = e.target.value;
    await saveSettings({ sidebar_side: side });
    const s = await getSettings();
    if (!s.floating) {
      if (side === 'right') {
        root.classList.add('ux-side-right');
      } else {
        root.classList.remove('ux-side-right');
      }
    }
  });

  root.querySelector('#ux-setting-timezone')?.addEventListener('change', async (e) => {
    await saveSettings({ timezone: e.target.value });
    updateUI().catch(() => {});
  });

  // Float toggle — move DOM node, never destroy+recreate
  root.querySelector('#ux-setting-float')?.addEventListener('change', async (e) => {
    const enable = e.target.checked;
    await saveSettings({ floating: enable });
    if (enable) {
      // Move from sidebar into body as floating panel
      const s = await getSettings();
      const fx = s.float_x != null ? s.float_x : window.innerWidth - 240;
      const fy = s.float_y != null ? s.float_y : window.innerHeight - 200;
      root.style.left = fx + 'px';
      root.style.top  = fy + 'px';
      root.classList.add('ux-floating');
      root.classList.remove('ux-side-right'); // Clean up sidebar side classes when entering float mode
      document.body.appendChild(root); // moves node — no clone
    } else {
      // Move back into sidebar
      root.classList.remove('ux-floating');
      root.style.left = '';
      root.style.top  = '';
      const s = await getSettings();
      if (s.sidebar_side === 'right') {
        root.classList.add('ux-side-right');
      } else {
        root.classList.remove('ux-side-right');
      }
      const sidebar = findInjectTarget();
      const userProfile = sidebar ? findUserProfileEl(sidebar) : null;
      if (sidebar && userProfile) {
        sidebar.insertBefore(root, userProfile);
      } else if (sidebar) {
        sidebar.appendChild(root);
      }
    }
    setupSidebarResizeObserver(root);
    updateUI().catch(() => {});
  });

  root.querySelector('#ux-btn-reset')?.addEventListener('click', async () => {
    await browser.storage.local.set({ today: freshToday(), history: [] });
    await updateUI();
  });

  root.querySelector('#ux-btn-clear-debug')?.addEventListener('click', async () => {
    await browser.storage.local.set({ debug_logs: [] });
    await updateUI();
  });

  // Draggable headers (active on home screen, settings screen, or advanced screen when floating)
  const handles = root.querySelectorAll('#ux-drag-handle, .ux-settings-header');
  if (handles.length > 0) {
    let dragging = false, ox = 0, oy = 0;
    handles.forEach(handle => {
      handle.addEventListener('mousedown', (e) => {
        if (!root.classList.contains('ux-floating')) return;
        // Avoid dragging when clicking buttons, selects, inputs, or links within the header
        if (e.target.closest('button, select, input, a')) return;
        dragging = true;
        ox = e.clientX - root.getBoundingClientRect().left;
        oy = e.clientY - root.getBoundingClientRect().top;
        root.style.transition = 'none';
        e.preventDefault();
      });
    });

    if (dragMoveHandler) document.removeEventListener('mousemove', dragMoveHandler);
    if (dragUpHandler) document.removeEventListener('mouseup', dragUpHandler);

    dragMoveHandler = (e) => {
      if (!dragging) return;
      const nx = Math.max(0, Math.min(window.innerWidth  - root.offsetWidth,  e.clientX - ox));
      const ny = Math.max(0, Math.min(window.innerHeight - root.offsetHeight, e.clientY - oy));
      root.style.left = nx + 'px';
      root.style.top  = ny + 'px';
    };

    dragUpHandler = async () => {
      if (!dragging) return;
      dragging = false;
      root.style.transition = '';
      const nx = parseFloat(root.style.left);
      const ny = parseFloat(root.style.top);
      await saveSettings({ float_x: nx, float_y: ny });
    };

    document.addEventListener('mousemove', dragMoveHandler);
    document.addEventListener('mouseup', dragUpHandler);
  }
}

// ─── Export helpers ────────────────────────────────────────────────────────────

async function exportData() {
  const res = await browser.storage.local.get(['today', 'history', 'settings', 'usage_limits', 'debug_logs']);
  download('usagex-export.json', JSON.stringify(res, null, 2));
}

function download(filename, text) {
  const a = document.createElement('a');
  a.href = 'data:application/json,' + encodeURIComponent(text);
  a.download = filename;
  a.click();
}

// ─── Debug logging ─────────────────────────────────────────────────────────────

async function debugLog(event, data) {
  const settings = await getSettings();
  if (!settings.debug_logging) return;
  const res = await browser.storage.local.get('debug_logs');
  const logs = res.debug_logs || [];
  const message = typeof data === 'object' ? JSON.stringify(data) : String(data);
  logs.push({
    timestamp: Date.now(),
    ts: new Date().toISOString(),
    event: event,
    scope: event,
    data: data,
    message: `${event}: ${message}`
  });
  if (logs.length > 500) logs.splice(0, logs.length - 500);
  await browser.storage.local.set({ debug_logs: logs });
}

// ─── HTML template ─────────────────────────────────────────────────────────────

function getSidebarHTML() {
  return `
<div id="ux-inner">
  <div id="ux-main-view">

    <div class="ux-header" id="ux-drag-handle">
      <div class="ux-title">
        <div class="ux-dot" id="ux-live-dot"></div>
        <span class="ux-name">Usage</span>
      </div>
      <div class="ux-icon-row">
        <button class="ux-icn" id="ux-btn-settings" aria-label="Settings" title="Settings">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
          </svg>
        </button>
        <button class="ux-icn" id="ux-btn-minimize" aria-label="Minimize" title="Minimize / Expand">
          <svg class="ux-icon-minimize" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
            <line x1="5" y1="12" x2="19" y2="12"/>
          </svg>
          <svg class="ux-icon-expand" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
            <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
          </svg>
        </button>
      </div>
    </div>

    <div id="ux-bars-section">
      <div class="ux-bar-item">
        <div class="ux-bar-top">
          <span class="ux-bar-label">Session (5h)</span>
          <span class="ux-pct" id="ux-session-pct">—</span>
        </div>
        <div class="ux-track"><div class="ux-fill ux-fill-session" id="ux-bar-session" style="width:0%"></div></div>
        <div class="ux-time" id="ux-session-time"></div>
      </div>

      <div class="ux-bar-item">
        <div class="ux-bar-top">
          <span class="ux-bar-label">Weekly</span>
          <span class="ux-pct" id="ux-weekly-pct">—</span>
        </div>
        <div class="ux-track"><div class="ux-fill ux-fill-weekly" id="ux-bar-weekly" style="width:0%"></div></div>
        <div class="ux-time" id="ux-weekly-time"></div>
      </div>
    </div>

    <div class="ux-action-row">
      <button class="ux-act-btn" id="ux-btn-export">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
        Export JSON
      </button>
      <button class="ux-act-btn" id="ux-btn-debug">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
        <span id="ux-debug-count">0 logs</span>
      </button>
    </div>
  </div>

  <div id="ux-settings-panel">
    <div class="ux-settings-header">
      <button class="ux-header-back-btn" id="ux-settings-back-btn" aria-label="Back" title="Back to Usage">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
          <line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>
        </svg>
      </button>
      <span class="ux-settings-title">Settings</span>
    </div>
    <div class="ux-setting-row">
      <span class="ux-setting-label">Float panel</span>
      <label class="ux-toggle">
        <input type="checkbox" id="ux-setting-float">
        <span class="ux-toggle-track"></span>
      </label>
    </div>
    <div class="ux-setting-row" id="ux-opacity-slider-row" style="display: none;">
      <span class="ux-setting-label">Panel opacity</span>
      <div style="display: flex; align-items: center; gap: 8px;">
        <input type="range" id="ux-setting-opacity-slider" min="10" max="100" step="5" class="ux-range-slider" style="width: 80px;">
        <span id="ux-opacity-val" style="font-size: 11.5px; color: var(--ux-text-2); min-width: 28px; text-align: right;">85%</span>
      </div>
    </div>
    <div class="ux-setting-row">
      <span class="ux-setting-label">Sidebar side</span>
      <select id="ux-setting-side" class="ux-select">
        <option value="left">Left</option>
        <option value="right">Right</option>
      </select>
    </div>
    <div class="ux-setting-row">
      <span class="ux-setting-label">Debug logging</span>
      <label class="ux-toggle">
        <input type="checkbox" id="ux-setting-debug">
        <span class="ux-toggle-track"></span>
      </label>
    </div>
    <button class="ux-advanced-btn" id="ux-advanced-btn">Advanced</button>
    <div class="ux-settings-btns">
      <button class="ux-settings-btn" id="ux-btn-reset">Reset local stats</button>
      <button class="ux-settings-btn" id="ux-btn-clear-debug">Clear debug logs</button>
    </div>
  </div>

  <div id="ux-advanced-panel">
    <div class="ux-settings-header">
      <button class="ux-header-back-btn" id="ux-advanced-back-btn" aria-label="Back" title="Back to Settings">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
          <line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>
        </svg>
      </button>
      <span class="ux-settings-title">Advanced</span>
    </div>
    <div class="ux-setting-row">
      <span class="ux-setting-label">Timezone</span>
      <select id="ux-setting-timezone" class="ux-select">
        <option value="auto">Auto-detect</option>
        <option value="IST">IST (UTC+5:30)</option>
        <option value="EST">EST (UTC-5)</option>
        <option value="CST">CST (UTC-6)</option>
        <option value="MST">MST (UTC-7)</option>
        <option value="PST">PST (UTC-8)</option>
        <option value="GMT">GMT (UTC+0)</option>
        <option value="CET">CET (UTC+1)</option>
        <option value="EET">EET (UTC+2)</option>
        <option value="MSK">MSK (UTC+3)</option>
        <option value="GST">GST (UTC+4)</option>
        <option value="PKT">PKT (UTC+5)</option>
        <option value="BST">BST (UTC+6)</option>
        <option value="WIB">WIB (UTC+7)</option>
        <option value="CST-Asia">CST (UTC+8)</option>
        <option value="JST">JST (UTC+9)</option>
        <option value="AEST">AEST (UTC+10)</option>
        <option value="NZST">NZST (UTC+12)</option>
      </select>
    </div>
    <div class="ux-setting-row">
      <span class="ux-setting-label">Floating opacity</span>
      <label class="ux-toggle">
        <input type="checkbox" id="ux-setting-floating-opacity-enabled">
        <span class="ux-toggle-track"></span>
      </label>
    </div>
  </div>

</div>`;
}

// ─── CSS ──────────────────────────────────────────────────

function getCSS() {
  return `
#usagex-v2-root {
  --ux-border: #2a2a2a;
  --ux-border-subtle: #232323;
  --ux-surface: #1c1c1c;
  --ux-surface-2: #222222;
  --ux-hover: #2c2c2c;
  --ux-accent: #cc9966;
  --ux-accent-dim: #b8895a;
  --ux-green-bright: #4e9b6a;
  --ux-red: #c0392b;
  --ux-text-1: #d4cdc5;
  --ux-text-2: #a09890;
  --ux-text-3: #706860;
  --ux-text-4: #4a4540;
  --ux-font: inherit;
  --ux-radius: 6px;
  font-family: var(--ux-font);
  font-size: 14px;
  line-height: 1.5;
  color: var(--ux-text-1);
  border-top: 1px solid var(--ux-border);
  box-sizing: border-box;
}
#usagex-v2-root.ux-parent-collapsed {
  display: none !important;
}
#usagex-v2-root *, #usagex-v2-root *::before, #usagex-v2-root *::after {
  box-sizing: inherit;
}
#usagex-v2-root.ux-floating {
  position: fixed;
  z-index: 2147483647;
  width: 224px;
  border-top: none;
  border: 1px solid var(--ux-border);
  border-radius: 12px;
  background: #181818;
  box-shadow: 0 16px 48px rgba(0,0,0,0.65), 0 4px 12px rgba(0,0,0,0.4);
  bottom: auto !important;
  right: auto !important;
  opacity: var(--ux-floating-opacity, 0.85);
  transition: opacity 0.2s ease-in-out;
}
#usagex-v2-root.ux-floating:hover {
  opacity: 1;
}
.ux-range-slider {
  -webkit-appearance: none;
  appearance: none;
  width: 80px;
  height: 5px;
  border-radius: 3px;
  background: linear-gradient(to right, var(--ux-accent) 0%, var(--ux-accent) var(--ux-slider-pct, 50%), #333 var(--ux-slider-pct, 50%), #333 100%);
  outline: none;
  cursor: pointer;
  transition: background 0.15s;
}
.ux-range-slider::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 15px;
  height: 15px;
  border-radius: 50%;
  background: var(--ux-text-1);
  border: 2px solid var(--ux-accent);
  box-shadow: 0 1px 4px rgba(0,0,0,0.4);
  cursor: grab;
  transition: transform 0.15s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.15s;
}
.ux-range-slider::-webkit-slider-thumb:hover {
  transform: scale(1.2);
  box-shadow: 0 0 0 3px rgba(204,153,102,0.2), 0 1px 4px rgba(0,0,0,0.4);
}
.ux-range-slider::-webkit-slider-thumb:active {
  cursor: grabbing;
  transform: scale(1.1);
}
.ux-range-slider::-moz-range-thumb {
  width: 15px;
  height: 15px;
  border-radius: 50%;
  background: var(--ux-text-1);
  border: 2px solid var(--ux-accent);
  box-shadow: 0 1px 4px rgba(0,0,0,0.4);
  cursor: grab;
}
.ux-range-slider::-moz-range-track {
  height: 5px;
  border-radius: 3px;
  background: #333;
}
#usagex-v2-root.ux-floating.ux-minimized { border-radius: 10px; }
#usagex-v2-root.ux-floating #ux-drag-handle,
#usagex-v2-root.ux-floating .ux-settings-header { cursor: grab; }
#usagex-v2-root.ux-floating #ux-drag-handle:active,
#usagex-v2-root.ux-floating .ux-settings-header:active { cursor: grabbing; }
#usagex-v2-root.ux-side-right {
  position: fixed;
  bottom: 28px;
  right: 18px;
  z-index: 99999;
  width: 224px;
  border-top: none;
  border: 1px solid var(--ux-border);
  border-radius: 12px;
  background: #181818;
  box-shadow: 0 8px 32px rgba(0,0,0,0.55);
}
#usagex-v2-root.ux-minimized #ux-bars-section,
#usagex-v2-root.ux-minimized .ux-action-row { display: none; }
#usagex-v2-root.ux-minimized .ux-header { margin-bottom: 0; }
.ux-icon-expand { display: none; }
#usagex-v2-root.ux-minimized .ux-icon-minimize { display: none; }
#usagex-v2-root.ux-minimized .ux-icon-expand  { display: block; }
#ux-settings-panel { display: none; }
#usagex-v2-root.ux-settings-open #ux-main-view  { display: none; }
#usagex-v2-root.ux-settings-open #ux-settings-panel { display: flex; flex-direction: column; }
#ux-advanced-panel { display: none; }
#usagex-v2-root.ux-advanced-open #ux-settings-panel { display: none; }
#usagex-v2-root.ux-advanced-open #ux-advanced-panel { display: flex; flex-direction: column; }
#ux-inner { padding: 13px 14px 12px; }
.ux-header {
  display: flex; align-items: center;
  justify-content: space-between;
  margin-bottom: 12px; user-select: none;
}
.ux-title { display: flex; align-items: center; gap: 7px; }
.ux-dot {
  width: 6px; height: 6px; border-radius: 50%;
  background: var(--ux-accent); flex-shrink: 0;
  animation: ux-pulse 3s ease-in-out infinite;
}
@keyframes ux-pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.35; }
}
.ux-name { font-size: 13px; font-weight: 600; color: var(--ux-text-1); letter-spacing: 0.01em; }
.ux-icon-row { display: flex; gap: 2px; }
.ux-icn {
  width: 26px; height: 26px; border-radius: 6px;
  border: 1px solid transparent; background: transparent;
  display: flex; align-items: center; justify-content: center;
  color: var(--ux-text-3); cursor: pointer; padding: 0;
  transition: background 0.15s, color 0.12s, border-color 0.12s;
}
.ux-icn:hover { background: var(--ux-hover); border-color: var(--ux-border); color: var(--ux-text-1); }
.ux-icn svg { display: block; transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1); }
.ux-icn:hover svg { transform: scale(1.18) rotate(-8deg); }
.ux-icn:active svg { transform: scale(0.92); transition-duration: 0.1s; }
#ux-bars-section { display: flex; flex-direction: column; gap: 10px; }
.ux-bar-top {
  display: flex; justify-content: space-between;
  align-items: baseline; margin-bottom: 5px;
}
.ux-bar-label { font-size: 13.5px; color: var(--ux-text-1); font-weight: 500; }
.ux-pct { font-size: 13.5px; font-weight: 600; color: var(--ux-accent); letter-spacing: -0.01em; }
.ux-track { height: 3px; background: #282828; border-radius: 2px; overflow: hidden; margin-bottom: 5px; }
.ux-fill { height: 100%; border-radius: 2px; transition: width 0.6s cubic-bezier(0.4,0,0.2,1); }
.ux-fill-session { background: var(--ux-accent); }
.ux-fill-weekly  { background: var(--ux-green-bright); }
.ux-time { font-size: 11.5px; color: var(--ux-text-3); line-height: 1.4; min-height: 16px; }
.ux-action-row { display: flex; gap: 8px; margin-top: 12px; }
.ux-act-btn {
  flex: 1; display: flex; align-items: center; justify-content: center; gap: 6px;
  padding: 8px 12px; background: rgba(255, 255, 255, 0.05);
  border: none; border-radius: var(--ux-radius);
  box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.08), 0 1px 2px rgba(0, 0, 0, 0.15);
  font-size: 12px; color: var(--ux-text-2); cursor: pointer;
  font-family: var(--ux-font); font-weight: 500;
  transition: background 0.15s ease, color 0.15s ease;
}
.ux-act-btn:hover { background: rgba(255, 255, 255, 0.1); color: var(--ux-text-1); }
.ux-act-btn svg { flex-shrink: 0; transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1); }
.ux-act-btn:hover svg { transform: translateY(-1px) scale(1.12); }
.ux-act-btn:active svg { transform: scale(0.9); transition-duration: 0.1s; }
.ux-settings-header {
  display: flex; align-items: center; gap: 8px;
  font-size: 13px; font-weight: 600; color: var(--ux-text-1);
  margin-bottom: 10px; padding-bottom: 8px; border-bottom: 1px solid var(--ux-border);
  user-select: none;
}
.ux-settings-title { flex: 1; letter-spacing: 0.01em; }
.ux-header-back-btn {
  flex-shrink: 0; width: 22px; height: 22px; border-radius: 5px;
  border: 1px solid transparent; background: transparent;
  display: flex; align-items: center; justify-content: center;
  color: var(--ux-text-3); cursor: pointer; padding: 0;
  transition: background 0.12s, color 0.12s, border-color 0.12s;
}
.ux-header-back-btn:hover { background: var(--ux-hover); border-color: var(--ux-border); color: var(--ux-text-1); }
.ux-header-back-btn svg { transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1); }
.ux-header-back-btn:hover svg { transform: translateX(-2px) scale(1.1); }
.ux-header-back-btn:active svg { transform: translateX(-1px) scale(0.92); transition-duration: 0.1s; }
.ux-setting-row {
  display: flex; align-items: center; justify-content: space-between;
  padding: 7px 0; border-bottom: 1px solid var(--ux-border-subtle);
}
.ux-setting-label { font-size: 13px; font-weight: 500; color: var(--ux-text-2); }
.ux-toggle { position: relative; width: 32px; height: 18px; flex-shrink: 0; }
.ux-toggle input { opacity: 0; width: 0; height: 0; position: absolute; }
.ux-toggle-track {
  position: absolute; inset: 0; background: #2a2a2a;
  border-radius: 9px; cursor: pointer; transition: background 0.2s; border: 1px solid #3a3a3a;
}
.ux-toggle-track::after {
  content: ""; position: absolute; width: 12px; height: 12px; left: 2px; top: 2px;
  background: #606060; border-radius: 50%; transition: transform 0.2s, background 0.2s;
}
.ux-toggle input:checked + .ux-toggle-track { background: #1a3020; border-color: #2a4a30; }
.ux-toggle input:checked + .ux-toggle-track::after { transform: translateX(14px); background: var(--ux-green-bright); }
.ux-select {
  background: var(--ux-surface); border: 1px solid var(--ux-border);
  border-radius: 5px; color: var(--ux-text-1); font-size: 11.5px;
  padding: 3px 7px; font-family: var(--ux-font); cursor: pointer;
  font-weight: 500; outline: none; transition: border-color 0.12s;
}
.ux-select:focus { border-color: var(--ux-accent-dim); }
.ux-advanced-btn {
  display: flex; align-items: center; justify-content: space-between;
  width: 100%; margin: 8px 0 6px; padding: 7px 0;
  background: transparent; border: none;
  border-bottom: 1px solid var(--ux-border-subtle);
  font-size: 13px; color: var(--ux-text-2); cursor: pointer;
  font-family: var(--ux-font); font-weight: 500; text-align: left; transition: color 0.12s;
}
.ux-advanced-btn::after { content: "\\203A"; font-size: 16px; color: var(--ux-text-4); }
.ux-advanced-btn:hover { color: var(--ux-text-1); }
.ux-settings-btns { display: flex; flex-direction: column; gap: 6px; margin-top: 9px; }
.ux-settings-btn {
  width: 100%; padding: 7px 0; background: rgba(255, 255, 255, 0.05);
  border: none; border-radius: var(--ux-radius);
  box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.08), 0 1px 2px rgba(0, 0, 0, 0.15);
  font-size: 12px; color: var(--ux-text-2); cursor: pointer;
  font-family: var(--ux-font); font-weight: 500;
  transition: background 0.15s ease, color 0.15s ease;
}
.ux-settings-btn:hover { background: rgba(255, 255, 255, 0.1); color: var(--ux-text-1); }
  `;
}

// ─── Active Usage limits fetching ──────────────────────────────────────────────

async function fetchUsageLimitsActive() {
  try {
    let orgId = document.cookie.split('; ').find(row => row.startsWith('lastActiveOrg='))?.split('=')[1] || null;
    
    if (!orgId) {
      const orgsRes = await fetch('/api/organizations');
      if (!orgsRes.ok) {
        await debugLog('active_fetch_failed', { status: orgsRes.status, stage: 'organizations' });
        return;
      }
      const orgs = await orgsRes.json();
      if (!Array.isArray(orgs) || orgs.length === 0) {
        await debugLog('active_fetch_failed', { reason: 'empty_orgs', stage: 'organizations' });
        return;
      }
      orgId = orgs[0].uuid;
    }
    
    if (!orgId) {
      await debugLog('active_fetch_failed', { reason: 'no_orgId' });
      return;
    }
    
    const usageRes = await fetch(`/api/organizations/${orgId}/usage`);
    if (!usageRes.ok) {
      await debugLog('active_fetch_failed', { status: usageRes.status, stage: 'usage', orgId });
      return;
    }
    const json = await usageRes.json();
    
    if (json.five_hour || json.seven_day) {
      const data = {
        session_pct: json.five_hour ? (json.five_hour.utilization ?? null) : null,
        session_resets_at: json.five_hour ? (json.five_hour.resets_at || null) : null,
        weekly_pct: json.seven_day ? (json.seven_day.utilization ?? null) : null,
        weekly_resets_at: json.seven_day ? (json.seven_day.resets_at || null) : null,
      };
      await browser.storage.local.set({ usage_limits: data });
      await updateUI();
      await debugLog('active_fetch_success', data);
    }
  } catch (err) {
    await debugLog('active_fetch_error', { message: err.message });
    console.error('[UsageX] Error active fetching usage limits:', err);
  }
}

function pollUsageLimits() {
  pollInterval = setInterval(async () => {
    await fetchUsageLimitsActive();
  }, 60000);
}

// ─── Init ──────────────────────────────────────────────────────────────────────

async function init() {
  injectFetchHook();
  await fetchUsageLimitsActive().catch(() => {});

  let attempts = 0;
  tryInjectInterval = setInterval(async () => {
    attempts++;
    if (sidebarInjected || attempts > 30) { clearInterval(tryInjectInterval); return; }
    await injectSidebar();
  }, 500);

  urlCheckInterval = setInterval(checkUrlChange, 1000);
  startTimeTracking();
  pollUsageLimits();

  let observerTimeout = null;
  globalObserver = new MutationObserver(() => {
    if (observerTimeout) clearTimeout(observerTimeout);
    observerTimeout = setTimeout(async () => {
      const existing = document.getElementById(UX_ID);
      const settings = await getSettings().catch(() => ({}));
      if (!existing) {
        sidebarInjected = false;
        await injectSidebar();
      } else if (!settings.floating && !existing.classList.contains('ux-floating')) {
        const sidebar = findInjectTarget();
        if (sidebar && existing.parentElement !== sidebar) {
          const userProfile = findUserProfileEl(sidebar);
          if (userProfile) {
            sidebar.insertBefore(existing, userProfile);
          } else {
            sidebar.appendChild(existing);
          }
          setupSidebarResizeObserver(existing);
        }
      }
    }, 100);
  });
  globalObserver.observe(document.body, { childList: true, subtree: true });
}

init();
